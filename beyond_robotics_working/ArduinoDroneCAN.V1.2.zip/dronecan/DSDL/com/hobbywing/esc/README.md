Hobbywing CAN ESC
=================

These messages are for the Hobbywing DroneCAN ESCs. These ESCs do not
use the standard uavcan.equipment.esc messages and instead implement
their own messages as given in this directory.

Note that the ESCs default to a CAN baud rate of 500000, but it can be
changed with the SetBaud command.

The default CAN NodeID is 1, and it can be changed with the SetID
command.
