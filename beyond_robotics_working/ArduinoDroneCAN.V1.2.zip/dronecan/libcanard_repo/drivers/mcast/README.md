# Libcanard Driver for multicast UDP

This driver allows to use Libcanard on systems supporting multicast UDP
