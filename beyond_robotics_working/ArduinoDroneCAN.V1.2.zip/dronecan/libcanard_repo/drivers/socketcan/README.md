# Libcanard Driver for Linux SocketCAN

This driver allows to use Libcanard on Linux over the [SocketCAN layer](https://en.wikipedia.org/wiki/SocketCAN).

There is no dedicated documentation, since the code is simple enough to be literally self-documenting.
At the time of writing this there was only 150 lines of it.
