# Libcanard Driver for the NuttX RTOS

This driver allows to use Libcanard with the NuttX RTOS.
