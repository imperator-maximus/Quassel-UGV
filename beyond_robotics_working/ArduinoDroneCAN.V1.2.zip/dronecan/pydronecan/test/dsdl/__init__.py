#
# Copyright (C) 2014-2015  UAVCAN Development Team  <uavcan.org>
# Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# This software is distributed under the terms of the MIT License.
#
# Define dsdl folder as module so python unittest autodiscover will
# work correctly
