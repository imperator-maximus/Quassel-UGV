#!/bin/sh
sudo rm -rf build uavcan.* dist*
