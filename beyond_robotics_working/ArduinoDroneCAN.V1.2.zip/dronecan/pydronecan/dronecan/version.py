#
# Copyright (C) 2014-2018  DroneCAN Development Team  <dronecan.org>
#
# This software is distributed under the terms of the MIT License.
#
# Author: Pavel Kirienko <pavel.kirienko@zubax.com>
#         Ben Dyer <ben_dyer@mac.com>
#         Andrew Tridgell
#         David Buzz
#

__version__ = '1.0.26'

