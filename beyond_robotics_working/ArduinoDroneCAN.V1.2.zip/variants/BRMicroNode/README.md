# BR Micro Node Variant

This project contains the files required for platformio to work for the Beyond Robotix Micro CAN node !

See https://github.com/BeyondRobotix/Arduino-DroneCAN 
