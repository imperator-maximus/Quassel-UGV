# ArduinoDroneCANlib
Arduino library to allow easy DroneCAN integration

Although this repo contains the actual library code, we use https://github.com/BeyondRobotix/Arduino-DroneCAN primarily!

See that repo for 
- examples
- folder structure
- support
