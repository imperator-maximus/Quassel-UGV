#ifndef APP
#define APP

extern "C"
{
    #include "stm32l4xx.h" // or stm32l431xx.h if needed
}
#include "Arduino.h"


void app_setup();

#endif // APP