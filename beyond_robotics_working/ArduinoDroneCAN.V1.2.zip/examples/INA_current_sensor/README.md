# INA current sensor example

This example illustrates how an already availible library can be used to easily integrate a new sensor into dronecan.

**this is untested code currently** I'll be able to test it at some point when I get an INA to hand.
